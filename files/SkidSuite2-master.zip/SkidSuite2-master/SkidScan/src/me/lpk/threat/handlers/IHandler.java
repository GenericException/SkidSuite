package me.lpk.threat.handlers;

public interface IHandler {
	String getName();
	String getDesc();
}
