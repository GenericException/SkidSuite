package me.lpk.hijack.exception;

public class BadInjectedReturnType extends RuntimeException {
	private static final long serialVersionUID = 1L;
}
