package me.lpk.obfuscation.rename;

import me.lpk.mapping.remap.MappingMode;

/**
 * TODO: This is a stupid name for just adding a 'getName' function.
 */
public abstract class MappingModeImpl extends MappingMode {

	public abstract String getName(String alphabet, int i);
}
