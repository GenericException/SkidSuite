package me.lpk.mapping.objects;

public class MappedMethod extends MappedMember {

	public MappedMethod(String original, String renamed, String desc) {
		super(original, renamed, desc);
	}

}
