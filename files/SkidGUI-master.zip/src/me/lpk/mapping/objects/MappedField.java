package me.lpk.mapping.objects;

public class MappedField extends MappedMember {
	public MappedField(String original, String renamed, String desc) {
		super(original, renamed, desc);
	}

}
