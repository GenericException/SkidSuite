Oh hey, you actually opened this. Give yourself a cookie, you deserve it.

PROBLEMS / BUG FIXING                                         
	Can't seem to get SkidGUI working with a specific jar file? Make sure you have all of that jar file's dependencies in the "jars" folder!
	How to find missing jars:
		- Run debug.bat (or edit it and make a non-windows equivalent. It just lets you see stacktraces)
		- Check for NoDef or ClassNotFound errors and google the classes that are missing (java2s.com/Code/Jar/ is a great start).
		- Download and drop jar files into "jars" folder
		- Restart SkidGUI
		
CONTACT
	Experiencing a bug? Have a suggestion? PM me
		- HF:uid=1828119
		- LF:user-131848
		- HE:uid=311